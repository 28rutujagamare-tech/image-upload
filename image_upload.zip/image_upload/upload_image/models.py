from django.db import models

# Create your models here.

class photo(models.Model):
    date=models.DateField(auto_now=True)
    description=models.TextField(max_length=20)
    title=models.CharField(max_length=10)
    pic=models.ImageField(upload_to="img")

