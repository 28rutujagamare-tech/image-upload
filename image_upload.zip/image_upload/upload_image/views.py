from django.shortcuts import render
from .models import photo
# Create your views here.

def home(request):
    if request.method =='POST':
        name=request.POST.get('name')
        Description=request.POST.get('Description')
        image=request.FILES.get('image')   
        photo.objects.create(
            title=name,
            description=Description,
            pic=image
        )
    data= photo.objects.all()
    return render(request,'home.html',{"data":data})

